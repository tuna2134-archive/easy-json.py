#easy_json

this can easy for json

How to use

usually version

```py
import easy_json

e=easy_json.mjson("data.json")

data=e.read()

print(data["test"])
#test

async version

```
import easy_json

e=easy_json.async