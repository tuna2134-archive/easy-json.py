#easy_json

this can easy for json

How to use

```py
import easy_json