#easy_json

this can easy for json